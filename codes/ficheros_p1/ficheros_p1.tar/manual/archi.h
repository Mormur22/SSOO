#define VAR 100

